package com.firstapp.kitcoek;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

public class SignUp extends AppCompatActivity {
    TextInputLayout regname, regusername, regemail, regmobilenumber, regpassword, regconfirmpassword;
    Button regsignup, reglogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        getSupportActionBar().setTitle("SignUp Form");
        regname = findViewById(R.id.fullName);
        regusername = findViewById(R.id.username);
        regemail = findViewById(R.id.email);
        regmobilenumber = findViewById(R.id.mobile_number);
        regpassword = findViewById(R.id.password);
        regsignup = findViewById(R.id.signUp);
        reglogin = findViewById(R.id.login);
        regconfirmpassword =findViewById(R.id.confirm_password);
        regsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateName(regname);
                validateUsername(regusername);
                validateEmail(regemail);
                validateMobile(regmobilenumber);
                validatePassword(regpassword);
                validateConfirmPassword(regconfirmpassword);

                if(!validateName(regname) | !validateUsername(regusername) | !validateEmail(regemail) | !validateMobile(regmobilenumber) |!validatePassword(regpassword) | !validateConfirmPassword(regconfirmpassword)){
                    return;
                }
                Intent signup = new Intent(SignUp.this, LoginWindow.class);
                startActivity(signup);
                Toast.makeText(getApplicationContext(), "Account created Succesfully", Toast.LENGTH_LONG).show();
                finish();
            }
        });
    }

    public void Login(View view) {
        Intent login = new Intent(SignUp.this, LoginWindow.class);
        startActivity(login);
        finish();
    }

    public boolean validateName(TextInputLayout regname) {
        String val = regname.getEditText().getText().toString();
        if (val.isEmpty()) {
            regname.setError("Field cannot be empty");
            return false;
        } else {
            regname.setError(null);
            regname.setEnabled(false);
            return true;
        }
    }

    private boolean validateUsername(TextInputLayout regusername) {
        String val = regusername.getEditText().getText().toString();
        String noWhiteSpace = "\\A\\w{4,15}\\z";
        if (val.isEmpty()) {
            regusername.setError("Field cannot be empty");
            return false;
        } else if (val.length() < 4 || val.length() > 15) {
            regusername.setError("Username length between 4 to 15 characters");
            return false;
        } else if (!val.matches(noWhiteSpace)) {
            regusername.setError("white spaces are not allowed");
            return false;
        } else {
            regusername.setError(null);
            regusername.setEnabled(false);
            return true;
        }
    }

    private boolean validateEmail(TextInputLayout regemail) {
        String val = regemail.getEditText().getText().toString();
        String emailpattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        if (val.isEmpty()) {
            regemail.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(emailpattern)) {
            regemail.setError("Please Enter Valid Email");
            return false;
        } else {
            regemail.setError(null);
            return true;
        }
    }

    private boolean validateMobile(TextInputLayout regmobilenumber) {
        String val = regmobilenumber.getEditText().getText().toString();
        String mobile = "[5-9]{1}[0-9]{9}";
        if (val.isEmpty()) {
            regmobilenumber.setError("Field cannot be empty");
            return false;
        }else if(!val.matches(mobile)) {
            regmobilenumber.setError("Please enter valid number");
            return false;
        }
        else {
            regmobilenumber.setError(null);
            return true;
        }
    }

    private boolean validatePassword(TextInputLayout regpassword) {
        String val = regpassword.getEditText().getText().toString();
        String passwordVal = "^"+"(?=.*[a-zA-Z])"+"(?=.*[@#$^&+=])"+"(?=\\S+$)"+".{6,}"+"$";
        if (val.isEmpty()) {
            regpassword.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(passwordVal)) {
            regpassword.setError("Please enter at least 6 digit password");
            return false;
        } else {
            regpassword.setError(null);
            regpassword.setEnabled(false);
            return true;
        }

    }
    private boolean validateConfirmPassword(TextInputLayout regconfirmpassword) {
        String val = regconfirmpassword.getEditText().getText().toString();
        String cp = regpassword.getEditText().getText().toString();
        String passwordVal = "^"+"(?=.*[a-zA-Z])"+"(?=.*[@#$^&+=])"+"(?=\\S+$)"+".{6,}"+"$";
        if (val.isEmpty()) {
            regconfirmpassword.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(passwordVal)) {
            regpassword.setError("Please enter at least 6 digit password");
            return false;
        }else if(!val.matches(cp)){
            regconfirmpassword.setError("Password does not match");
            return false;
        }
        else {
            regconfirmpassword.setError(null);
            regconfirmpassword.setEnabled(false);
            return true;
        }

    }


}
package com.firstapp.kitcoek;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

public class ForgotPassword extends AppCompatActivity {
    TextInputLayout funame, femail, fpass, fcpass;
    Button fsubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        getSupportActionBar().setTitle("Forget Password");

        funame = findViewById(R.id.username);
        femail = findViewById(R.id.email);
        fpass = findViewById(R.id.newPassword);
        fcpass = findViewById(R.id.confirm_password);
        fsubmit = findViewById(R.id.submit_area);
        fsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateUname(funame);
                validateEmail(femail);
                validatePassword(fpass);
                validateCPassword(fcpass);

                if (!validateUname(funame) | !validateEmail(femail) | !validatePassword(fpass) | !validateCPassword(fcpass)) {
                    return;
                }
                Intent submit = new Intent(ForgotPassword.this, LoginWindow.class);
                startActivity(submit);
                Toast.makeText(getApplicationContext(), "Password Reset Succesfully", Toast.LENGTH_LONG).show();
                finish();

            }
        });

    }

    public void Cancle (View view){
        Intent cancle = new Intent(ForgotPassword.this, LoginWindow.class);
        startActivity(cancle);
        finish();
    }
    private boolean validateUname(TextInputLayout funame) {
        String val = funame.getEditText().getText().toString();
        String noWhiteSpace = "\\A\\w{4,15}\\z";
        if (val.isEmpty()) {
            funame.setError("Field cannot be empty");
            return false;
        } else if (val.length() < 4 || val.length() > 15) {
            funame.setError("Username length between 4 to 15 characters");
            return false;
        } else if (!val.matches(noWhiteSpace)) {
            funame.setError("white spaces are not allowed");
            return false;
        } else {
            funame.setError(null);
            funame.setEnabled(false);
            return true;
        }
    }
    private boolean validateEmail(TextInputLayout femail) {
        String val = femail.getEditText().getText().toString();
        String emailpattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        if (val.isEmpty()) {
            femail.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(emailpattern)) {
            femail.setError("Please Enter Valid Email");
            return false;
        } else {
            femail.setError(null);
            return true;
        }
    }
    private boolean validatePassword(TextInputLayout fpass) {
        String val = fpass.getEditText().getText().toString();
        String passwordVal = "^"+"(?=.*[a-zA-Z])"+"(?=.*[@#$^&+=])"+"(?=\\S+$)"+".{6,}"+"$";
        if (val.isEmpty()) {
            fpass.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(passwordVal)) {
            fpass.setError("Please enter at least 6 digit password");
            return false;
        } else {
            fpass.setError(null);
            fpass.setEnabled(false);
            return true;
        }

    }
    private boolean validateCPassword(TextInputLayout fcpass) {
        String val = fcpass.getEditText().getText().toString();
        String cp = fpass.getEditText().getText().toString();
        String passwordVal = "^"+"(?=.*[a-zA-Z])"+"(?=.*[@#$^&+=])"+"(?=\\S+$)"+".{6,}"+"$";
        if (val.isEmpty()) {
            fcpass.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(passwordVal)) {
            fcpass.setError("Please enter at least 6 digit password");
            return false;
        }else if(!val.matches(cp)){
            fcpass.setError("Password does not match");
            return false;
        }
        else {
            fcpass.setError(null);
            fcpass.setEnabled(false);
            return true;
        }

    }
}

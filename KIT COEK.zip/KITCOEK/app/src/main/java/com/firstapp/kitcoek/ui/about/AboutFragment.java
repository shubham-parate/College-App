package com.firstapp.kitcoek.ui.about;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.firstapp.kitcoek.R;

import java.util.ArrayList;
import java.util.List;

public class AboutFragment extends Fragment {

    private ViewPager viewPager;
    private BranchAdapter adapter;
    private List<BranchModel> list;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_about, container, false);

        list = new ArrayList<>();
        list.add(new BranchModel(R.drawable.ic_computer, "Computer Science", "The Computer Science and Engineering Department was started in the year 1999 with intake capacity of 60 seats. From 2018, the Department has an additional intake of 60 students, so total intake is 180 students."));
        list.add(new BranchModel(R.drawable.ic_mech, "Mechanical Engineering", "The objective of the Department is to empower the faculty, staff and aspiring Engineers with essential technical knowledge and skills. The Department has well qualified and highly experienced faculty and staff."));
        list.add(new BranchModel(R.drawable.ic_civil, "Civil Engineering", "Civil Engineering is one of the basic and core branches of Engineering, having a large influence on common man’s living. It emphasizes on the technical uplift of the common man and guides common man through application of the technical knowledge for the welfare of the society."));
        list.add(new BranchModel(R.drawable.ic_elecrical,"Elecetical Engineering","We at KIT’s College of Engineering Autonomous have started a new U.G. Programme in Electrical Engineering since 2018 with an intake capacity of 60 students. The department conducts four years Bachelor of Engineering in Electrical Engineering degree course affiliated to Shivaji University."));
        list.add(new BranchModel(R.drawable.ic_electronic,"Electronic Engineering","This department has been running a U.G. course in Electronics Engineering since 1983. It has to its credit an excellent track record in terms of students’ academic performance over the years. Students consistently feature among the ‘top ten rankers’ at the university level."));
        list.add(new BranchModel(R.drawable.ic_entc,"EnTC Engineering","The department of Electronics and Telecommunication is one of the premier department of the KIT College. The department of Electronics and Telecommunication Engineering was started during the year 2007 with the undergraduate program."));
        list.add(new BranchModel(R.drawable.ic_biotech, "Biotech Engineering", "KIT’s College of Engineering Kolhapur took an early note of the significant role that was to be played by Biotechnology Engineers in future industrial development of biotechnology related processes and products by establishing department of Biotechnology Engineering in 2002."));
        list.add(new BranchModel(R.drawable.ic_it,"IT Engineering","Department of Information Technology is the only NBA Accredited IT Department in Shivaji University. The department was established in the year 2001 with intake capacity of 60 students. Ours is department of differences and uniqueness. The success story is seen by the ‘alumni’."));
        list.add(new BranchModel(R.drawable.ic_bsh, "BSH Department","Around 800 students, 12 divisions, 14 Basic Sciences, Humanities, and Engineering Sciences and Foreign Languages courses is brief introduction of the department. The aim of the department is to mould students and start their journey as professional engineers."));


        adapter = new BranchAdapter(getContext(), list);

        viewPager = view.findViewById(R.id.viewPager);

        viewPager.setAdapter(adapter);

        ImageView imageView = view.findViewById(R.id.college_image);

        Glide.with(getContext()).load("https://firebasestorage.googleapis.com/v0/b/kit-admin-61380.appspot.com/o/gallery%2F%5BB%401d1183bjpg?alt=media&token=3baa3aeb-8dfe-4a2a-8352-ba464c4f6b8c").into(imageView);

        return view;
    }
}
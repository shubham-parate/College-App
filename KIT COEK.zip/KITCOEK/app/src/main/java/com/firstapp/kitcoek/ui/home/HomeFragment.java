package com.firstapp.kitcoek.ui.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.firstapp.kitcoek.R;
import com.smarteist.autoimageslider.DefaultSliderView;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderLayout;

import java.util.zip.Inflater;

public class HomeFragment extends Fragment {

    private SliderLayout sliderLayout;
    private ImageView map;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_home, container, false);

        sliderLayout = view.findViewById(R.id.slider);
        sliderLayout.setIndicatorAnimation(IndicatorAnimations.FILL);
        sliderLayout.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderLayout.setScrollTimeInSec(1);

        setSliderViews();

        map = view.findViewById(R.id.map);
        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMap();
            }
        });

        return view;
    }

    private void openMap() {
        Uri uri = Uri.parse("geo:0,0?q=Kit College Of Engineering");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.setPackage("com.google.android.apps.maps");
        startActivity(intent);
    }

    private void setSliderViews() {
        for(int i = 0; i<5; i++){
            DefaultSliderView sliderView = new DefaultSliderView(getContext());

            switch (i){
                    case 0:
                    sliderView.setImageUrl("https://firebasestorage.googleapis.com/v0/b/kit-admin-61380.appspot.com/o/gallery%2F%5BB%401d1183bjpg?alt=media&token=72cbe7e8-7e0b-421b-af71-e61c9f35a184");
                    break;

                    case 1:
                    sliderView.setImageUrl("https://firebasestorage.googleapis.com/v0/b/kit-admin-61380.appspot.com/o/gallery%2F%5BB%4062eb90djpg?alt=media&token=42f309c8-db62-4803-8ea3-d293c4b85dcf");
                    break;

                    case 2:
                    sliderView.setImageUrl("https://firebasestorage.googleapis.com/v0/b/kit-admin-61380.appspot.com/o/gallery%2F%5BB%40852f67bjpg?alt=media&token=8cabd939-6b4c-4fb2-bf1f-b1a3440d807e");
                    break;

                    case 3:
                    sliderView.setImageUrl("https://firebasestorage.googleapis.com/v0/b/kit-admin-61380.appspot.com/o/gallery%2F%5BB%40240b538jpg?alt=media&token=56bd89b8-88c3-48b5-a132-47d5f8cbf191");
                    break;

                    case 4:
                    sliderView.setImageUrl("https://firebasestorage.googleapis.com/v0/b/kit-admin-61380.appspot.com/o/gallery%2F%5BB%40b2e94bbjpg?alt=media&token=6862ef49-3e4b-43f1-8458-668257243eb2");
                    break;

            }
            sliderView.setImageScaleType(ImageView.ScaleType.FIT_CENTER);

            sliderLayout.addSliderView(sliderView);
        }
    }
}
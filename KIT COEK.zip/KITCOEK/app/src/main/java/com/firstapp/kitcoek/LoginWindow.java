package com.firstapp.kitcoek;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

public class LoginWindow extends AppCompatActivity {
    TextView textView, textView1;
    TextInputLayout username, password;
    Button signin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_window);


        textView = findViewById(R.id.text);
        textView1 = findViewById(R.id.forget_password);
        username = findViewById(R.id.username);
        password =findViewById(R.id.password);
        signin = findViewById(R.id.login);

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateUsername(username);
                validatePassword(password);

                if(!validateUsername(username) | !validatePassword(password)){
                    return;
                }
                Intent signin = new Intent(LoginWindow.this, MainActivity.class);
                startActivity(signin);
                Toast.makeText(getApplicationContext(),"Login Successful",Toast.LENGTH_SHORT).show();
                finish();
            }
        });
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signup = new Intent(LoginWindow.this, SignUp.class);
                startActivity(signup);
                finish();
            }
        });
        textView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent forgetPassword = new Intent(LoginWindow.this,ForgotPassword.class);
                startActivity(forgetPassword);
                finish();
            }
        });
    }

    private boolean validateUsername(TextInputLayout username) {
        String val = username.getEditText().getText().toString();
        String noWhiteSpace = "\\A\\w{4,15}\\z";
        if (val.isEmpty()) {
            username.setError("Field cannot be empty");
            return false;
        } else if (val.length() < 4 || val.length() > 15) {
            username.setError("Username length between 4 to 15 characters");
            return false;
        } else if (!val.matches(noWhiteSpace)) {
            username.setError("white spaces are not allowed");
            return false;
        } else {
            username.setError(null);
            username.setEnabled(false);
            return true;
        }
    }
    private boolean validatePassword(TextInputLayout password) {
        String val = password.getEditText().getText().toString();
        String passwordVal = "^"+"(?=.*[a-zA-Z])"+"(?=.*[@#$^&+=])"+"(?=\\S+$)"+".{6,}"+"$";
        if (val.isEmpty()) {
            password.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(passwordVal)) {
            password.setError("Please enter at least 6 digit password");
            return false;
        } else {
            password.setError(null);
            password.setEnabled(false);
            return true;
        }

    }
   

}
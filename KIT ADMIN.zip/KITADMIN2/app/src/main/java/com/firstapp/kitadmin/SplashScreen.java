package com.firstapp.kitadmin;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class SplashScreen extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        ActionBar obj =getSupportActionBar();
        obj.hide();

    }
    @Override
    protected void onResume() {
        super.onResume();
        MyThread t =new MyThread();
        t.start();
    }

    class MyThread extends Thread{
        public void run(){
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Intent i2 = new Intent(SplashScreen.this, MainActivity.class);
            startActivity(i2);
            finish();
        }

    }
}